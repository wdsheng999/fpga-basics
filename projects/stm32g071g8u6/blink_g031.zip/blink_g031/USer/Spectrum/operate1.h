#ifndef __OPERATE_H__
#define __OPERATE_H__

#include "app1.h"

void Spectrum_Operate_Init(void);
void Spectrum_Operate_DeInit(void);

void Spectrum_Operate_Try_Process(void);

#endif
