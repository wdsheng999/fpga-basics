#ifndef __SPECTRUM_UI__
#define __SPECTRUM_UI__

#include "app1.h"

void Spectrum_UI_Init(void);
void Spectrum_UI_DeInit(void);

void Spectrum_UI_Try_Refresh(uint8_t force);

#endif
