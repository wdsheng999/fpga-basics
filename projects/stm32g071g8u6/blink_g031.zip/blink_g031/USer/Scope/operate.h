#ifndef __SCOPE_OPERATE_H__
#define __SCOPE_OPERATE_H__

#include "app.h"

void Scope_Operate_Init(void);
void Scope_Operate_DeInit(void);

void Scope_Operate_Try_Process(void);

#endif
