#ifndef __SCOPE_UI_H__
#define __SCOPE_UI_H__

#include "app.h"

void Scope_UI_Init(void);
void Scope_UI_DeInit(void);

void Scope_UI_Try_Refresh(uint8_t force);

#endif
